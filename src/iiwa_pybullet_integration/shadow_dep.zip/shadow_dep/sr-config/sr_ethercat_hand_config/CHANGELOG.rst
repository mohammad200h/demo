^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package sr_ethercat_hand_config
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.4.0 (2015-04-07)
------------------
* Fix J0 names for effort controllers
* Fix diagnostics prefix
* Add bimanual diagnostic analyzer
* Add pwm_control argument
* Adapt config files to bimanual single loop
* adding tactile controller config for easier customer customisation

1.3.0 (2014-02-14)
------------------
* first hydro release
