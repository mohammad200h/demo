# common_resources
This repository contains resources that are common to all Shadow Robot's robots
