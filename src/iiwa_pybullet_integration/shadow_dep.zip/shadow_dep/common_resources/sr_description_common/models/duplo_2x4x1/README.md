This folder include two different simplified models.

The one defined in `model_simplified.sdf` is a translucent box used for mating map visualisation in Gazebo.

The one defined in `meshes/duplo_2x4x1_simplified.*` is a hollow-shell model for use in object recognition.
