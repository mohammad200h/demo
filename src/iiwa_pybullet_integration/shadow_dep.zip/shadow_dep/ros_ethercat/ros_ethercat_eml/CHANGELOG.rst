^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ros_ethercat_eml
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.0 (2015-04-07)
------------------
* Delete unnecessary class EtherCAT_SlaveDb that was causing sigsegv
* Make the start address non-static (each ethercat port will have its own separate logical address space)
* bug fixes in initialization

0.1.8 (2014-07-18)
------------------

0.1.7 (2014-05-23)
------------------

0.1.6 (2014-05-15)
------------------

0.1.5 (2014-05-14)
------------------

0.1.4 (2014-05-14)
------------------

0.1.3 (2014-05-13)
------------------

0.1.2 (2014-05-13)
------------------

0.1.1 (2014-05-12)
------------------
* first hydro release
