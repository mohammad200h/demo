^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package sr_edc_ethercat_drivers
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.4.0 (2015-04-07)
------------------
* Fixed loop counter for tactile publisher throttling to be at 100Hz
* Fix serial to string conversion
* Set node handle from ouside the robot_lib. Prefix the diagnostics.
* Add ns_prefix and joint_prefix to hand devices.

1.3.1 (2014-07-18)
------------------

1.3.0 (2014-02-14)
------------------
* first hydro release

