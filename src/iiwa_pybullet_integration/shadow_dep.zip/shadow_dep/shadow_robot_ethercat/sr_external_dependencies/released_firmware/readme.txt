simplemotor.hex       - This is the firmware for normal motors.
simplemotor_no_bc.hex - This is a version with backlash compensation disabled.
                        It may help the control in thumb joint 4 and 5 (motors 9 & 19).