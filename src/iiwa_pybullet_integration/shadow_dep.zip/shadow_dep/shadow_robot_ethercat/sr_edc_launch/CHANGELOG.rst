^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package sr_edc_launch
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.4.0 (2015-04-07)
------------------
* Rename ros_grant
* Add launchfile for a bimanual system in a single process
* replace pr2-grant with ros_grant
* UBI0.cpp, sr_motor_robot_lib.cpp and sr_muscle_robot_lib now match upstream
  Removed sr_bringup as calibration file is now in ros_ethercat
* now using calibrate.py in sr_mechanism_controllers

1.3.1 (2014-07-18)
------------------

1.3.0 (2014-02-14)
------------------
* first hydro release

