|     Service       |  Status  |
| ----------------- | -------- |
| Code style checks | [![Circle CI](https://circleci.com/gh/shadow-robot/ros_control_robot.svg?style=shield)](https://circleci.com/gh/shadow-robot/ros_control_robot) |
| Unit tests        | [![Build Status](https://img.shields.io/shippable/56444f251895ca4474233f19.svg)](https://app.shippable.com/projects/56444f251895ca4474233f19) |
| Install tests     | [![Build Status](https://semaphoreci.com/api/v1/projects/3de2d648-2eee-42a9-92a2-cb8d7aa37390/657662/shields_badge.svg)](https://semaphoreci.com/shadow-robot/ros_control_robot) |
| Code Coverage     | [![codecov.io](https://codecov.io/github/shadow-robot/ros_control_robot/coverage.svg?branch=indigo-devel)](https://codecov.io/github/shadow-robot/ros_control_robot?branch=indigo-devel) |

# ros_control_robot
Implementation of a generic multi-robot ros_control loop
