^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ethercat_grant
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.1 (2016-12-29)
------------------

0.2.0 (2016-12-29)
------------------
* Modify postinst script

0.1.1 (2015-04-10)
------------------
* Modify postinst script

0.1.0 (2015-04-07)
------------------
* Add postinstallation script
* Change package name
