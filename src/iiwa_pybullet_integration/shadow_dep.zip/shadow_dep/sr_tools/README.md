|     Service       |  Status  |
| ----------------- | -------- |
| Documentation     | [![Documentation Status](https://readthedocs.org/projects/shadow-robot-tools/badge/?version=latest)](http://shadow-robot-tools.readthedocs.org) |
| Code style checks | [![Circle CI](https://circleci.com/gh/shadow-robot/sr_tools.svg?style=shield)](https://circleci.com/gh/shadow-robot/sr_tools) |
| Unit tests        | [![Build Status](https://img.shields.io/shippable/55e049031895ca447410960d.svg)](https://app.shippable.com/projects/55e049031895ca447410960d) |
| Install tests     | [![Build Status](https://semaphoreci.com/api/v1/projects/ff5c2a15-6179-4d60-a6c3-d5a15af31282/525235/shields_badge.svg)](https://semaphoreci.com/shadow-robot/sr_tools) |
| Code Coverage     | [![codecov.io](https://img.shields.io/codecov/c/github/shadow-robot/sr_tools/indigo-devel.svg)](http://codecov.io/github/shadow-robot/sr_tools?branch=indigo-devel) |

# Shadow Robot Tools packages
This repository contains more advanced tools that might be needed in specific use cases.
