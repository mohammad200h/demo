# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/localadmin/catkin_ws/src/iiwa_fri_stack/fri_client_sdk/include".split(';') if "/home/localadmin/catkin_ws/src/iiwa_fri_stack/fri_client_sdk/include" != "" else []
PROJECT_CATKIN_DEPENDS = "".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lfri_client_sdk".split(';') if "-lfri_client_sdk" != "" else []
PROJECT_NAME = "fri_client_sdk"
PROJECT_SPACE_DIR = "/home/localadmin/catkin_ws/src/iiwa_fri_stack/fri_client_sdk/cmake-build-debug/devel"
PROJECT_VERSION = "1.11.0"
