# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/usr/local/include".split(';') if "/usr/local/include" != "" else []
PROJECT_CATKIN_DEPENDS = "".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lfri_client_sdk".split(';') if "-lfri_client_sdk" != "" else []
PROJECT_NAME = "fri_client_sdk"
PROJECT_SPACE_DIR = "/usr/local"
PROJECT_VERSION = "1.11.0"
