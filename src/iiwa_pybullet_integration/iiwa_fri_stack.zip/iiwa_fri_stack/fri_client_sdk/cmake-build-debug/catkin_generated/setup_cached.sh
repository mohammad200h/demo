#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/localadmin/catkin_ws/src/iiwa_fri_stack/fri_client_sdk/cmake-build-debug/devel:$CMAKE_PREFIX_PATH"
export LD_LIBRARY_PATH="/opt/ros/kinetic/share/euslisp/jskeus/eus//Linux64/lib:/home/localadmin/sr_ws/devel/lib:/home/localadmin/catkin_ws/devel/lib:/opt/ros/kinetic/lib:/opt/ros/kinetic/lib/x86_64-linux-gnu:/home/localadmin/.local/share/JetBrains/Toolbox/apps/CLion/ch-0/172.4343.16/bin:/opt/ros/kinetic/share/euslisp/jskeus/eus//Linux64/lib:/opt/ros/kinetic/share/euslisp/jskeus/eus//Linux64/lib:/opt/ros/kinetic/share/euslisp/jskeus/eus//Linux64/lib:/opt/ros/kinetic/share/euslisp/jskeus/eus//Linux64/lib"
export PATH="/opt/ros/kinetic/share/euslisp/jskeus/eus//Linux64/bin:/opt/ros/kinetic/bin:/opt/ros/kinetic/share/euslisp/jskeus/eus//Linux64/bin:/opt/ros/kinetic/share/euslisp/jskeus/eus//Linux64/bin:/opt/ros/kinetic/share/euslisp/jskeus/eus//Linux64/bin:/opt/ros/kinetic/share/euslisp/jskeus/eus//Linux64/bin:/home/localadmin/bin:/home/localadmin/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin"
export ROSLISP_PACKAGE_DIRECTORIES="/home/localadmin/catkin_ws/src/iiwa_fri_stack/fri_client_sdk/cmake-build-debug/devel/share/common-lisp:$ROSLISP_PACKAGE_DIRECTORIES"
export ROS_PACKAGE_PATH="/home/localadmin/catkin_ws/src/iiwa_fri_stack/fri_client_sdk:$ROS_PACKAGE_PATH"